---------------------------------------
Default Resource Groups
---------------------------------------
Version: 1.0.0
Author: John Peca <john@modx.com>
---------------------------------------

This plugin allows you to specify default resource groups based on context level.

You can create a properties for this plugin with same name as context keys and as a value set comma delimited list of default resource groups.

Plugin can also preserve the default resource groups after each save, which means that resource will stay in its defaults resource group even when user uncheck them.